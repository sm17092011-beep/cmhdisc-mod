package com.mert.cmhdisc;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.JukeboxSong;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

@Mod(CanYouFeelMyHeartDisc.MOD_ID)
public class CanYouFeelMyHeartDisc {
    public static final String MOD_ID = "cmhdisc";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);

    public static final ResourceKey<JukeboxSong> SONG_KEY =
            ResourceKey.create(Registries.JUKEBOX_SONG,
                    ResourceLocation.fromNamespaceAndPath(MOD_ID, "can_you_feel_my_heart"));

    public static final DeferredHolder<SoundEvent, SoundEvent> CAN_YOU_FEEL_MY_HEART_SOUND =
            SOUNDS.register("can_you_feel_my_heart", () ->
                    SoundEvent.createVariableRangeEvent(
                            ResourceLocation.fromNamespaceAndPath(MOD_ID, "can_you_feel_my_heart")));

    public static final DeferredHolder<Item, Item> CAN_YOU_FEEL_MY_HEART_DISC =
            ITEMS.register("can_you_feel_my_heart_disc", () ->
                    new RecordItem(15, CAN_YOU_FEEL_MY_HEART_SOUND,
                            new Item.Properties()
                                    .stacksTo(1)
                                    .rarity(Rarity.RARE)
                                    .jukeboxPlayable(SONG_KEY),
                            360));

    public CanYouFeelMyHeartDisc(IEventBus modEventBus) {
        SOUNDS.register(modEventBus);
        ITEMS.register(modEventBus);
        LOGGER.info("Can You Feel My Heart Disc mod loaded!");
    }
}
