MERT'İN CAN YOU FEEL MY HEART MÜZİK DİSKİ MODU
Minecraft 1.21.1 - NeoForge

ÖNEMLİ:
Bu ZIP, modun kaynak proje dosyalarıdır; hazır derlenmiş .jar değildir.
Şarkının telifli ses dosyası pakete eklenmemiştir. Modun müzik çalması için
yasal olarak kullanma hakkına sahip olduğun bir ses dosyasını OGG Vorbis'e
çevirip aşağıdaki konuma koymalısın:

src/main/resources/assets/cmhdisc/sounds/can_you_feel_my_heart.ogg

Dosya adını aynen yaz. MP3 dosyasını sadece yeniden adlandırmak yetmez;
gerçekten OGG Vorbis formatına dönüştürmelisin.

DERLEME:
1. Java 21 kurulu olsun.
2. Bu klasörü aç.
3. Windows'ta terminal/CMD açıp bu klasöre gel.
4. gradle kuruluysa: gradle build
   (İlk derlemede Gradle, Minecraft/NeoForge dosyalarını internetten indirir.)
5. Başarılı olursa build/libs/can_you_feel_my_heart_disc-1.0.0.jar oluşur.
6. Bu JAR dosyasını Minecraft'ın mods klasörüne koy.
7. Minecraft profilinin 1.21.1 NeoForge olduğundan emin ol.

OYUNDA:
Yaratıcı mod envanterinde "Can You Feel My Heart" diskini ara.
Diski müzik kutusuna koy.

ŞARKI:
Bring Me The Horizon - Can You Feel My Heart
